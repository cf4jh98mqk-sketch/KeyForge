import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.08, green: 0.08, blue: 0.1, alpha: 1)
        setupUI()
    }

    func setupUI() {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 32),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -32)
        ])

        let iconLabel = UILabel()
        iconLabel.text = "⌨️"
        iconLabel.font = UIFont.systemFont(ofSize: 64)
        stack.addArrangedSubview(iconLabel)

        let titleLabel = UILabel()
        titleLabel.text = "KeyForge"
        titleLabel.font = UIFont.systemFont(ofSize: 34, weight: .bold)
        titleLabel.textColor = .white
        stack.addArrangedSubview(titleLabel)

        let subtitleLabel = UILabel()
        subtitleLabel.text = "Custom Font Keyboard"
        subtitleLabel.font = UIFont.systemFont(ofSize: 17)
        subtitleLabel.textColor = UIColor(red: 0, green: 1, blue: 1, alpha: 0.8)
        stack.addArrangedSubview(subtitleLabel)

        let divider = UIView()
        divider.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        divider.heightAnchor.constraint(equalToConstant: 1).isActive = true
        divider.widthAnchor.constraint(equalToConstant: 260).isActive = true
        stack.addArrangedSubview(divider)

        let instructions = [
            ("1", "Open Settings on your iPad"),
            ("2", "Go to General → Keyboard → Keyboards"),
            ("3", "Tap \"Add New Keyboard...\""),
            ("4", "Select \"KeyForge\" from the list"),
            ("5", "Tap KeyForge → Allow Full Access (optional)"),
            ("6", "Switch to KeyForge using the globe key")
        ]

        for (num, text) in instructions {
            let row = UIStackView()
            row.axis = .horizontal
            row.spacing = 12
            row.alignment = .top

            let numLabel = UILabel()
            numLabel.text = num
            numLabel.font = UIFont.monospacedSystemFont(ofSize: 14, weight: .bold)
            numLabel.textColor = UIColor(red: 0, green: 1, blue: 1, alpha: 1)
            numLabel.widthAnchor.constraint(equalToConstant: 20).isActive = true
            row.addArrangedSubview(numLabel)

            let textLabel = UILabel()
            textLabel.text = text
            textLabel.font = UIFont.systemFont(ofSize: 15)
            textLabel.textColor = UIColor.white.withAlphaComponent(0.85)
            textLabel.numberOfLines = 0
            row.addArrangedSubview(textLabel)

            stack.addArrangedSubview(row)
            row.widthAnchor.constraint(equalTo: stack.widthAnchor).isActive = true
        }
    }
}
