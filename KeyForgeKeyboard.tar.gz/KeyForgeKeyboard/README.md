# KeyForge — Custom Font iPad Keyboard

A real iOS custom keyboard extension that renders your chosen font on every key.
Install it on your iPad using a Windows PC — no Mac required.

---

## Overview

- **KeyForgeKeyboard/** — the container app (required by Apple; shows install instructions on device)
- **KeyboardExtension/** — the actual keyboard that appears in every app including iMessage
- **.github/workflows/** — automatically builds the IPA in the cloud for free

---

## Windows Install Guide (No Mac needed)

### Step 1 — Add your font
Replace `KeyboardExtension/CustomFont.ttf` with your own `.ttf` file.
The filename must stay exactly `CustomFont.ttf`.

### Step 2 — Create a free GitHub account
Go to https://github.com and sign up if you don't have an account.

### Step 3 — Create a new repository
1. Click the **+** icon → New repository
2. Name it `keyforge-keyboard`
3. Set it to **Public**
4. Click **Create repository**

### Step 4 — Upload these project files
On your new repo page, click **uploading an existing file**.
Drag the entire `KeyForgeKeyboard` folder contents into the upload area.
Commit the files.

### Step 5 — Wait for the build (~5 minutes)
GitHub automatically runs the build workflow.
Go to the **Actions** tab in your repo to watch it.
When it shows a green checkmark, it's done.

### Step 6 — Download the IPA
1. Click the completed workflow run
2. Scroll to **Artifacts** at the bottom
3. Click **KeyForgeKeyboard-IPA** to download it
4. Unzip the downloaded file — you'll get `KeyForgeKeyboard.ipa`

### Step 7 — Install Sideloadly on Windows
Download from https://sideloadly.io — it's free.

### Step 8 — Sideload the IPA onto your iPad
1. Connect your iPad to your Windows PC via USB
2. Open Sideloadly
3. Drag `KeyForgeKeyboard.ipa` into Sideloadly
4. Enter your Apple ID (the free one is fine)
5. Click **Start**
6. Enter your Apple ID password when prompted
7. Wait for it to finish installing

### Step 9 — Trust the app on iPad
1. Open **Settings → General → VPN & Device Management**
2. Tap your Apple ID email
3. Tap **Trust**

### Step 10 — Enable the keyboard
1. Settings → General → Keyboard → Keyboards
2. Tap **Add New Keyboard...**
3. Select **KeyForge**

### Step 11 — Use it in iMessage
Open iMessage, tap the text field, then long-press the 🌐 globe key → select **KeyForge**.

---

## Re-signing (every 7 days with free Apple ID)

Free Apple IDs expire apps every 7 days. Just repeat Step 8 — plug in, open Sideloadly, install again. It only takes 30 seconds.

If you have a paid Apple Developer account ($99/year), apps stay installed permanently.

---

## Customizing colors

Open `KeyboardExtension/KeyboardViewController.swift` and change these values:

```swift
var keyColor: UIColor = UIColor(red: 0.16, green: 0.16, blue: 0.21, alpha: 1)   // key background
var keyTextColor: UIColor = UIColor(red: 0, green: 1, blue: 1, alpha: 1)         // key labels
var boardBgColor: UIColor = UIColor(red: 0.08, green: 0.08, blue: 0.1, alpha: 1) // board background
var fontSize: CGFloat = 18
```

After changing, push to GitHub → wait for build → download new IPA → sideload again.

---

## Troubleshooting

**"App could not be installed" in Sideloadly** — Make sure your iPad is trusted on the PC (tap Trust on the iPad when connected).

**Keyboard not appearing in list** — Open the KeyForge app on your iPad first, then go to Settings.

**Font not showing on keys** — The file must be named exactly `CustomFont.ttf` and be a valid TTF file.

**GitHub Actions failed** — Go to the Actions tab, click the failed run, and read the error. Usually it's a missing file.
